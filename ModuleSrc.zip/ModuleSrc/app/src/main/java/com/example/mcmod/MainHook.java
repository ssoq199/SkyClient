package com.example.mcmod;

import android.content.Context;
import android.content.Intent;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.netease.x19")) return;
        XposedHelpers.findAndHookMethod("android.app.ActivityThread", lpparam.classLoader,
                "handleBindApplication", "android.app.ActivityThread$AppBindData",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Context context = (Context) XposedHelpers.callMethod(param.thisObject, "getSystemContext");
                        if (context != null) {
                            context.startService(new Intent(context, FloatingService.class));
                        }
                    }
                });
        hookGameLoop(lpparam.classLoader);
    }

    private void hookGameLoop(ClassLoader loader) {
        try {
            Class<?> mcClass = Class.forName("net.minecraft.client.Minecraft", true, loader);
            XposedHelpers.findAndHookMethod(mcClass, "runTick", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object mc = param.thisObject;
                    Object player = XposedHelpers.callMethod(mc, "getPlayer");
                    if (player == null) return;
                    if (AutoBridge.isEnabled()) AutoBridge.placeWideBridge(player, mc);
                    if (AutoKill.isEnabled()) AutoKill.killAura(player, mc, 6.0);
                }
            });
        } catch (Throwable t) { /* 类名可能混淆，忽略 */ }
    }
}
