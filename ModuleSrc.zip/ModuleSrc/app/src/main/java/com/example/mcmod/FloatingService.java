package com.example.mcmod;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private View floatBtn, panel;
    private boolean open = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createButton();
        createPanel();
        return START_STICKY;
    }

    private void createButton() {
        floatBtn = new TextView(this);
        floatBtn.setBackgroundResource(R.drawable.circle_bg);
        floatBtn.setText("K");
        floatBtn.setTextColor(android.graphics.Color.WHITE);
        floatBtn.setTextSize(30);
        floatBtn.setGravity(Gravity.CENTER);
        floatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { togglePanel(); }
        });
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(160, 160,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 30; p.y = 200;
        wm.addView(floatBtn, p);
    }

    private void createPanel() {
        panel = LayoutInflater.from(this).inflate(R.layout.panel_layout, null);
        Switch swBridge = panel.findViewById(R.id.switch_bridge);
        swBridge.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                AutoBridge.setEnabled(isChecked);
            }
        });
        Switch swKill = panel.findViewById(R.id.switch_kill);
        swKill.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                AutoKill.setEnabled(isChecked);
            }
        });
        panel.setVisibility(View.GONE);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.CENTER;
        wm.addView(panel, p);
    }

    private void togglePanel() {
        open = !open;
        panel.setVisibility(open ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroy() {
        if (floatBtn != null) wm.removeView(floatBtn);
        if (panel != null) wm.removeView(panel);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
