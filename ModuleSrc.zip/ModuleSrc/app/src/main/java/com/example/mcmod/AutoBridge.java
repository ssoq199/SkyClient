package com.example.mcmod;

import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.Method;

public class AutoBridge {
    private static boolean enabled = false;
    public static void setEnabled(boolean e) { enabled = e; }
    public static boolean isEnabled() { return enabled; }

    public static void placeWideBridge(Object player, Object mc) {
        try {
            Object pos = XposedHelpers.callMethod(player, "getPosition");
            double x = (double) XposedHelpers.callMethod(pos, "getX");
            double y = (double) XposedHelpers.callMethod(pos, "getY");
            double z = (double) XposedHelpers.callMethod(pos, "getZ");
            float yaw = (float) XposedHelpers.getFloatField(player, "yaw");
            float rad = (float) Math.toRadians(yaw);
            float dx = (float) -Math.sin(rad);
            float dz = (float) Math.cos(rad);
            int baseX = (int) Math.floor(x + dx * 3);
            int baseY = (int) Math.floor(y) - 1;
            int baseZ = (int) Math.floor(z + dz * 3);
            float leftX = -dz;
            float leftZ = dx;
            Object world = XposedHelpers.callMethod(mc, "getWorld");
            if (world == null) return;
            Method setBlock = findSetBlockMethod(world.getClass());
            if (setBlock == null) return;
            for (int i = -1; i <= 1; i++) {
                int targetX = baseX + (int) (leftX * i);
                int targetZ = baseZ + (int) (leftZ * i);
                setBlock.invoke(world, targetX, baseY, targetZ, getBlockState("stone"));
            }
        } catch (Throwable t) { /* ignore */ }
    }

    private static Method findSetBlockMethod(Class<?> clazz) {
        for (Method m : clazz.getDeclaredMethods()) {
            Class<?>[] params = m.getParameterTypes();
            if (params.length == 4 &&
                (params[0] == int.class || params[0] == Integer.class) &&
                (params[1] == int.class || params[1] == Integer.class) &&
                (params[2] == int.class || params[2] == Integer.class)) {
                m.setAccessible(true);
                return m;
            }
        }
        return null;
    }

    private static Object getBlockState(String id) { return null; }
}
