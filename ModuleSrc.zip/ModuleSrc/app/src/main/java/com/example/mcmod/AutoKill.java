package com.example.mcmod;

import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.Method;
import java.util.List;

public class AutoKill {
    private static boolean enabled = false;
    public static void setEnabled(boolean e) { enabled = e; }
    public static boolean isEnabled() { return enabled; }

    public static void killAura(Object player, Object mc, double range) {
        try {
            Object world = XposedHelpers.callMethod(mc, "getWorld");
            if (world == null) return;
            List<?> entities = (List<?>) XposedHelpers.callMethod(world, "getEntities");
            if (entities == null) return;
            Object pos = XposedHelpers.callMethod(player, "getPosition");
            double px = (double) XposedHelpers.callMethod(pos, "getX");
            double py = (double) XposedHelpers.callMethod(pos, "getY");
            double pz = (double) XposedHelpers.callMethod(pos, "getZ");
            Method attackMethod = findAttackMethod(player.getClass());
            if (attackMethod == null) return;
            for (Object entity : entities) {
                if (entity == player) continue;
                if (!isLivingEntity(entity)) continue;
                Object ePos = XposedHelpers.callMethod(entity, "getPosition");
                double ex = (double) XposedHelpers.callMethod(ePos, "getX");
                double ey = (double) XposedHelpers.callMethod(ePos, "getY");
                double ez = (double) XposedHelpers.callMethod(ePos, "getZ");
                double dist = Math.sqrt((px-ex)*(px-ex) + (py-ey)*(py-ey) + (pz-ez)*(pz-ez));
                if (dist > range) continue;
                float yaw = (float) Math.toDegrees(Math.atan2(ez - pz, ex - px)) - 90;
                float pitch = (float) Math.toDegrees(Math.atan2((ey + 1.5) - py, Math.sqrt((ex-px)*(ex-px) + (ez-pz)*(ez-pz))));
                XposedHelpers.setFloatField(player, "yaw", yaw);
                XposedHelpers.setFloatField(player, "pitch", pitch);
                boolean onGround = (boolean) XposedHelpers.getBooleanField(player, "onGround");
                if (onGround) XposedHelpers.setFloatField(player, "motionY", 0.42f);
                attackMethod.invoke(player, entity);
            }
        } catch (Throwable t) { /* ignore */ }
    }

    private static Method findAttackMethod(Class<?> clazz) {
        for (Method m : clazz.getDeclaredMethods()) {
            if (m.getName().toLowerCase().contains("attack") ||
                m.getName().toLowerCase().contains("hit")) {
                m.setAccessible(true);
                return m;
            }
        }
        return null;
    }

    private static boolean isLivingEntity(Object obj) {
        String name = obj.getClass().getName();
        return name.contains("Living") || name.contains("EntityPlayer") || name.contains("EntityMonster");
    }
}
